package mad.madhu53;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.CorrectionInfo;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainBody extends AppCompatActivity implements View.OnClickListener {
    private Button[][] button = new Button[3][3];
    private boolean player1turn = true;
    private int count;
    private int player1score;
    private int player2score;
    private TextView text1player, text2player;
    String[] question = {"1+3 = 2", "KMnO4 + HCl = MnCl2 + KCl + Cl2 + H2O","sin(A+B)=sinAcosB-sinBcosA", "“戶樞不蠹”中的“蠹”指的是蟲蛀。",
            "Fe + Cl2 = Fe2Cl3", "Array is not fixed size", "String is reference type", "machine language is low-level languages",
            "Javascript is not similar to C++", "Bach is romantic period composer", "All end chord in Baroque period is in major key",
            "PVC can be recycle"};





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_body);

        text1player = findViewById(R.id.text_view_p1);
        text2player = findViewById(R.id.text_view_p2);



        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "btn_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                button[i][j] = findViewById(resID);
                button[i][j].setOnClickListener(this);


            }
        }
        Button btnAgain = findViewById(R.id.btn_again);
        btnAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();

            }
        });

    }


    @Override
    public void onClick(View v) {
        //check if there is game start
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }
        //first person is x then next is o
        if (player1turn) {
            alertClick(v);
            if ( correct("True")) {
                ((Button) v).setText("x");
            }else{
                ((Button) v).setText("");
            }
        }else {
            alertClick(v);
            if ( correct("True")) {
                ((Button) v).setText("o");
            }else{
                ((Button) v).setText("");
            }
        }


        count++;
        if (checkWin()) {
            if (player1turn) {
                play1Win();
            } else {
                play2Win();
            }
        } else if (count == 9) {
            draw();
        } else {
            player1turn = !player1turn;
        }
    }



    //here is checking how to win
    private boolean checkWin() {
        String[][] field = new String[3][3];
        //first loop the button value to field
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = button[i][j].getText().toString();

            }
        }
        //check if row are the same
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1]) &&
                    field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }

        }
        //check if column are the same
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i]) &&
                    field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }

        }
        //check if the diagonal is the same
        for (int i = 0; i < 3; i++) {
            if (field[0][0].equals(field[1][1]) &&
                    field[0][0].equals(field[2][2])
                    && !field[0][0].equals("")) {
                return true;
            }

        }
        //check if the diagonal is the same
        for (int i = 0; i < 3; i++) {
            if (field[0][2].equals(field[1][1]) &&
                    field[0][2].equals(field[2][0])
                    && !field[0][2].equals("")) {
                return true;
            }

        }
        return false;
    }

    //action to do if someone win
    private void play1Win() {
        player1score++;
        Toast.makeText(this, "First player win!!", Toast.LENGTH_SHORT).show();
        updateScore();
        replay();
    }

    private void play2Win() {
        player2score++;
        Toast.makeText(this, "Second player win!!", Toast.LENGTH_SHORT).show();
        updateScore();
        replay();
    }

    //if draw
    private void draw() {
        Toast.makeText(this, "Draw!!", Toast.LENGTH_SHORT).show();
        replay();
    }

    // update the point
    private void updateScore() {
        text1player.setText("First Player: " + player1score);
        text2player.setText("First Player: " + player2score);
    }


    private void replay() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                button[i][j].setText("");
            }
        }
        count = 0;
        player1turn = true;

    }

    private void reset() {
        player1score = 0;
        player2score = 0;
        updateScore();
        replay();

    }

    //if the device is rotate then it can save the data
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("count", count);
        outState.putInt("player1score", player1score);
        outState.putInt("player2score", player2score);
        outState.putBoolean("player1turn", player1turn);

    }

    //presenting the data
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        count = savedInstanceState.getInt("count");
        player1score = savedInstanceState.getInt("player1score");
        player2score = savedInstanceState.getInt("player1score");
        player1turn = savedInstanceState.getBoolean("player1turn");
    }

    public void alertClick(View v) {
        //create a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Answer the question: True or False! Correct then get the place.");//Title of the dialog
        //contact
        builder.setMessage(question());
        builder.setCancelable(false);//allow cancel
        //for making correct answer button


        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainBody.this, "Answer finished", Toast.LENGTH_SHORT).show();
                correct("True");
                dialog.cancel();

            }


        });
        //the false button
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainBody.this, "Answer finished", Toast.LENGTH_SHORT).show();
                correct("false");
                dialog.cancel();
            }

        });

        builder.show();

    }




    private String question(){//1T 2T 3F 4T 5F 6F 7T 8T 9F 10F 11T 12F
        Random random = new Random();
        int randomNumber = random.nextInt(12);
        String qs;
        qs = question[randomNumber];
        return qs;

    }

    private int index(){
        String q="";
        int x = 0;
        for (int i=0; i<question.length; i++){
            q = question[i];
            if (question().equals(q)){
                break;
            }
            x= i;
        }
        return x;
    }




    private boolean correct(String value){
        String[] ans = {"True","True","False","True","False","False","True","True","False","False","True","False"};
        if(value == ans[index()]){
            return true;
        }

        return false;
    }


}



