package mad.madhu53;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.CorrectionInfo;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainBody extends AppCompatActivity implements View.OnClickListener {
    private Button[][] button = new Button[3][3];
    private boolean player1turn = true;
    private int count;
    private int player1score;
    private int player2score;
    private TextView text1player, text2player;
    String[] question = {"Build a Campfire: To find dry fuel," +
         /*1*/   "Place the material next to your cheek; if it feels cool, it's too wet to burn efficiently. To fuel a 1-hour fire, gather two large fistfuls of tinder--such as cattail down and crushed pine needles--and about 30 twigs, 20 pencil-size sticks and 10 wrist-thick pieces. Form a tepee with three 6-in.-tall sticks and place smaller sticks on the floor as a platform for the tinder.\n" +
            "\n" + "Lean the smallest sticks on the tepee, leaving a doorway to face the wind. Place the next size of sticks on top; repeat twice. Pack the tepee with the tinder and light it. Slowly add the 10 largest sticks in a star pattern.\n" +
            "TIP: If it's raining, Laskowski uses a cotton ball smeared with Vaseline (or ChapStick) as a foolproof fire starter." ,
        /*2*/ "Wax a Car: Park the car in the shade, or work after sunset to keep hot sunshine off the paint. Wash the car thoroughly with a cleaner that won't strip off old wax, as household detergent does. Rub the wax on in a circular motion, one panel at a time. Give it a few minutes to haze up, then buff off with terry cloth or microfiber polishing cloths.","sin(A+B)=sinAcosB-sinBcosA",

        /*3*/ "The Perfect Pushup: Feet should be no farther than 12 in. apart, hands about shoulder-width. \"Your body is in a straight line from heels to shoulders,\" Kaplan says. Bend your elbows to lower your body as a single unit until your upper arms are parallel to the ground. Return to the starting position, with arms fully extended. Repeat until ordered to stop.",

        /*4*/ "Move Heavy Stuff: The favorite heavy-moving tool of Chris Wells, driver-owner-operator of A-Mrazek Moving Systems, is ... a blanket. \"Tilt one end of the object up and bunch the blanket underneath, then tilt the other end up and pull the blanket through, so that the object is sitting on the blanket. Then it's easy to pull it wherever you want it to go.\"",
       /*5*/  "Time Management Tips: Keep everything in perspective. You're smart—and there are many tools and strategies for making the most of what you have.",
       /*6*/  "Tips for Becoming a Great Public Speaker: Slow Down, most inexperienced speakers talk faster on stage than they realize – and it’s completely understandable. ",
      /*7*/ "Tips for Becoming a Great Public Speaker: Pay Attention to Your Body Language, why so importance? Non-verbal communication – of which your body language is a large part – compliments verbal communication. Your posture, the way you hold yourself, the way you move your hands… all these facets of body language can help to refine and reinforce what you’re talking about.",
      /*8*/ "You should sleep with your door closed. Sleeping with your doors closed will help protect you from smoke and toxic fumes in the event of a fire. And for more information on how to rest better at night, check out these 50 Tips for Your Best Sleep Ever.",

      /*9*/ "Taking aspirin during a heart attack may save your life.",

      /*10*/ "The universe has a color. The name of color is  \"cosmic latte.\".",
      /*11*/  "You can blur your house on Google's street view."};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_body);

        text1player = findViewById(R.id.text_view_p1);
        text2player = findViewById(R.id.text_view_p2);



        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "btn_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                button[i][j] = findViewById(resID);
                button[i][j].setOnClickListener(this);


            }
        }
        Button btnAgain = findViewById(R.id.btn_again);
        btnAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();

            }
        });

    }


    @Override
    public void onClick(View v) {
        //check if there is game start
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }
        //first person is x then next is o
        if (player1turn) {
            alertClick(v);
            ((Button) v).setText("x");
            }else{
                alertClick(v);
                ((Button) v).setText("o");
            }

        count++;




        if (checkWin()) {
            if (player1turn) {
                play1Win();
            } else {
                play2Win();
            }
        } else if (count == 9) {
            draw();
        } else {
            player1turn = !player1turn;
        }
    }



    //here is checking how to win
    private boolean checkWin() {
        String[][] field = new String[3][3];
        //first loop the button value to field
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = button[i][j].getText().toString();

            }
        }
        //check if row are the same
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1]) &&
                    field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }

        }
        //check if column are the same
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i]) &&
                    field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }

        }
        //check if the diagonal is the same
        for (int i = 0; i < 3; i++) {
            if (field[0][0].equals(field[1][1]) &&
                    field[0][0].equals(field[2][2])
                    && !field[0][0].equals("")) {
                return true;
            }

        }
        //check if the diagonal is the same
        for (int i = 0; i < 3; i++) {
            if (field[0][2].equals(field[1][1]) &&
                    field[0][2].equals(field[2][0])
                    && !field[0][2].equals("")) {
                return true;
            }

        }
        return false;
    }

    //action to do if someone win
    private void play1Win() {
        player1score++;
        Toast.makeText(this, "First player win!!", Toast.LENGTH_SHORT).show();
        updateScore();
        replay();
    }

    private void play2Win() {
        player2score++;
        Toast.makeText(this, "Second player win!!", Toast.LENGTH_SHORT).show();
        updateScore();
        replay();
    }

    //if draw
    private void draw() {
        Toast.makeText(this, "Draw!!", Toast.LENGTH_SHORT).show();
        replay();
    }

    // update the point
    private void updateScore() {
        text1player.setText("First Player: " + player1score);
        text2player.setText("First Player: " + player2score);
    }


    private void replay() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                button[i][j].setText("");
            }
        }
        count = 0;
        player1turn = true;

    }

    private void reset() {
        player1score = 0;
        player2score = 0;
        updateScore();
        replay();

    }

    //if the device is rotate then it can save the data
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("count", count);
        outState.putInt("player1score", player1score);
        outState.putInt("player2score", player2score);
        outState.putBoolean("player1turn", player1turn);

    }

    //presenting the data
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        count = savedInstanceState.getInt("count");
        player1score = savedInstanceState.getInt("player1score");
        player2score = savedInstanceState.getInt("player1score");
        player1turn = savedInstanceState.getBoolean("player1turn");
    }

    public void alertClick(View v) {
        //create a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Have a look on some useful living knowledge");//Title of the dialog
        //contact
        builder.setMessage(question());
        builder.setCancelable(false);//allow cancel
        //for making correct answer button


        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainBody.this, "Hope it help you", Toast.LENGTH_SHORT).show();

                dialog.cancel();

            }
        });
        //the false button
        builder.show();

    }




    private String question(){//1T 2T 3F 4T 5F 6F 7T 8T 9F 10F 11T 12F
        Random random = new Random();
        int randomNumber = random.nextInt(12);
        String qs;
        qs = question[randomNumber];
        return qs;

    }






}



