package mad.madhu53;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    private Button mystory,appidea;
    private ImageButton aboutme;
    private ImageView bg_imgView;
    private TextView txt;
    private VideoView videoView;


    MediaPlayer myMus = null;// a field of MediaPlayer
    @Override
    protected void onResume(){ // callback method, when interacting with user
        super.onResume(); // always call superclass
        if (myMus != null) myMus.start(); // start playing
    }
    @Override
    protected void onPause(){ // callback method, inactive: when no interacting
        super.onPause(); // always call superclass
        if (myMus != null) myMus.pause(); // pause playing
    }


    public void initRotateBgImg(){
        // animate rotation of background image
        RotateAnimation animR = new RotateAnimation(0f, 360f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        animR.setInterpolator(new LinearInterpolator());
        animR.setRepeatCount(Animation.INFINITE);
        animR.setDuration(6000);
        // Simple scaling the background image view
        ImageView imgV = ((ImageView) findViewById(R.id.bg_imgView));
        imgV.setScaleX(2); imgV.setScaleY(2);
        // Start animating (rotating) the background image view
        imgV.startAnimation(animR);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initRotateBgImg();

        myMus = MediaPlayer.create(this, R.raw.bs);//sound file “bs” in raw folder
        myMus.setLooping(true);



        mystory = (Button) findViewById(R.id.mystory);
        appidea = (Button) findViewById(R.id.appidea);
        aboutme = (ImageButton) findViewById(R.id.aboutme);
        txt = (TextView) findViewById(R.id.txt);



        mystory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StoryBehind.class);
                startActivity(intent);
            }
        });


        aboutme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AboutMe.class);
                startActivity(intent);
            }
        });

        appidea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainBody.class);
                startActivity(intent);
            }
        });


    }





}